@echo off
echo Starting School Bus Route Planner API...
start "Bus Route API" cmd /k "python bus_route_planner.py --serve"
timeout /t 2 /nobreak >nul
echo Starting map server...
start "Bus Route Map" cmd /k "cd frontend && python -m http.server 8000"
timeout /t 2 /nobreak >nul
start "" http://127.0.0.1:8000
