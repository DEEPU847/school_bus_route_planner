const API = "http://127.0.0.1:5000";
const map = L.map("map").setView([17.3850, 78.4867], 12);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

let mode = null;
let school = null;
let schoolMarker = null;
let stops = {};
let markers = {};
let routeLine = null;
let nextStop = 1;
let routeData = null;

const statusEl = document.getElementById("apiStatus");
const listEl = document.getElementById("stopList");
const resultsEl = document.getElementById("results");
const schoolIcon = L.divIcon({
  className: "custom-marker",
  html: '<div class="marker-pin school-pin">S</div>',
  iconSize: [34, 34], iconAnchor: [17, 34], popupAnchor: [0, -32]
});
const stopIcon = L.divIcon({
  className: "custom-marker",
  html: '<div class="marker-pin stop-pin">B</div>',
  iconSize: [34, 34], iconAnchor: [17, 34], popupAnchor: [0, -32]
});

async function checkApi() {
  try {
    const r = await fetch(API + "/api/health");
    if (!r.ok) throw new Error();
    statusEl.textContent = "API connected";
    statusEl.style.background = "#dcfce7";
  } catch {
    statusEl.textContent = "API offline — start Python server";
    statusEl.style.background = "#fee2e2";
  }
}
checkApi();

document.getElementById("setSchool").onclick = () => {
  mode = "school";
  alert("Click the map to place the school.");
};

document.getElementById("addStop").onclick = () => {
  mode = "stop";
  alert("Click the map to add a student stop.");
};

document.getElementById("clearAll").onclick = () => {
  if (schoolMarker) map.removeLayer(schoolMarker);
  Object.values(markers).forEach(m => map.removeLayer(m));
  if (routeLine) map.removeLayer(routeLine);
  school = null; schoolMarker = null; stops = {}; markers = {}; nextStop = 1; routeData = null;
  renderStops(); resultsEl.innerHTML = "";
};

map.on("click", e => {
  if (!mode) return;

  if (mode === "school") {
    if (schoolMarker) map.removeLayer(schoolMarker);
    school = { lat: e.latlng.lat, lng: e.latlng.lng };
    if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
    schoolMarker = L.marker(e.latlng, { draggable: true, icon: schoolIcon })
      .addTo(map).bindPopup("<b>School</b>").openPopup();
    schoolMarker.on("dragend", ev => {
      const p = ev.target.getLatLng();
      school.lat = p.lat; school.lng = p.lng; if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
    });
  } else if (mode === "stop") {
    const name = "Stop " + nextStop++;
    stops[name] = { lat: e.latlng.lat, lng: e.latlng.lng, students: 1, priority: "Medium" };
    if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
    const marker = L.marker(e.latlng, { draggable: true, icon: stopIcon }).addTo(map);
    marker.bindPopup("<b>" + name + "</b><br>Click the stop in the panel to edit it.");
    marker.on("dragend", ev => {
      const p = ev.target.getLatLng();
      stops[name].lat = p.lat; stops[name].lng = p.lng; if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
    });
    markers[name] = marker;
    renderStops();
  }
  mode = null;
});

function renderStops() {
  const names = Object.keys(stops);
  if (!names.length) {
    listEl.innerHTML = '<div class="empty">No stops yet.</div>';
    return;
  }

  listEl.innerHTML = names.map(name => {
    const s = stops[name];
    return `<div class="stop-card">
      <strong>${name}</strong>
      <div class="row"><label>Students <input type="number" min="1" value="${s.students}" data-name="${name}" data-field="students"></label></div>
      <div class="row"><label>Priority
        <select data-name="${name}" data-field="priority">
          <option ${s.priority==="High"?"selected":""}>High</option>
          <option ${s.priority==="Medium"?"selected":""}>Medium</option>
          <option ${s.priority==="Low"?"selected":""}>Low</option>
        </select>
      </label></div>
      <div class="row"><button onclick="removeStop('${name}')">Remove</button></div>
    </div>`;
  }).join("");

  listEl.querySelectorAll("[data-field]").forEach(el => {
    el.onchange = () => {
      const name = el.dataset.name;
      const field = el.dataset.field;
      stops[name][field] = field === "students" ? Number(el.value) : el.value;
    };
  });
}

window.removeStop = function(name) {
  if (markers[name]) map.removeLayer(markers[name]);
  delete markers[name];
  delete stops[name];
  if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
  routeData = null;
  renderStops();
};


function downloadText(filename, text) {
  const blob = new Blob([text], {type: "application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

document.getElementById("saveData").onclick = () => {
  if (!school && !Object.keys(stops).length) return alert("There is no map data to save.");
  const payload = {
    version: 1,
    school,
    stops,
    capacity: Number(document.getElementById("capacity").value)
  };
  downloadText("bus_route_plan.json", JSON.stringify(payload, null, 2));
};

document.getElementById("loadData").onclick = () => {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".json,application/json";
  input.onchange = () => {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data.school && !data.stops) throw new Error("Invalid route file.");
        document.getElementById("clearAll").click();

        if (data.school) {
          school = data.school;
          schoolMarker = L.marker([school.lat, school.lng], {
            draggable: true, icon: schoolIcon
          }).addTo(map).bindPopup("<b>School</b>");
          schoolMarker.on("dragend", ev => {
            const p = ev.target.getLatLng();
            school.lat = p.lat; school.lng = p.lng;
            if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
          });
        }

        stops = data.stops || {};
        nextStop = 1;
        Object.keys(stops).forEach(name => {
          const n = Number(name.replace("Stop ", ""));
          if (Number.isFinite(n)) nextStop = Math.max(nextStop, n + 1);
          const s = stops[name];
          const marker = L.marker([s.lat, s.lng], {
            draggable: true, icon: stopIcon
          }).addTo(map).bindPopup("<b>" + name + "</b>");
          marker.on("dragend", ev => {
            const p = ev.target.getLatLng();
            stops[name].lat = p.lat; stops[name].lng = p.lng;
            if (routeLine) { map.removeLayer(routeLine); routeLine = null; }
          });
          markers[name] = marker;
        });

        if (data.capacity) document.getElementById("capacity").value = data.capacity;
        renderStops();
        if (school) map.setView([school.lat, school.lng], 13);
        alert("Route data loaded.");
      } catch (err) {
        alert("Could not load the file: " + err.message);
      }
    };
    reader.readAsText(file);
  };
  input.click();
};

document.getElementById("planRoute").onclick = async () => {
  if (!school) return alert("Set the school location first.");
  if (!Object.keys(stops).length) return alert("Add at least one stop.");

  const body = {
    school,
    stops,
    capacity: Number(document.getElementById("capacity").value)
  };

  try {
    const response = await fetch(API + "/api/plan", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(body)
    });
    const data = await response.json();
    routeData = data;
    if (!response.ok) throw new Error(data.error || "Route calculation failed");

    if (routeLine) map.removeLayer(routeLine);
    routeLine = L.polyline(data.route_coordinates, {weight: 5}).addTo(map);
    map.fitBounds(routeLine.getBounds(), {padding: [30,30]});

    resultsEl.innerHTML = `
      <h3>Route Result</h3>
      <div class="metric"><span>Distance</span><b>${data.total_distance_km} km</b></div>
      <div class="metric"><span>Time</span><b>${data.estimated_time_min} min</b></div>
      <div class="metric"><span>Students</span><b>${data.students_picked}/${data.capacity}</b></div>
      <div class="metric"><span>High priority</span><b>${data.priority_stops_served}</b></div>
      <div class="log"><b>Pickup order:</b><br>${data.pickup_order.join(" → ")}</div>
      <div class="log"><b>Route path:</b><br>${data.full_path.join(" → ")}</div>
      ${data.unreachable_stops.length ? `<div class="warning">Unreachable: ${data.unreachable_stops.join(", ")}</div>` : ""}
      <div class="log"><b>Algorithm decisions:</b>${data.decision_log.map(x => `<div>• ${x}</div>`).join("")}</div>
    `;
  } catch (err) {
    alert(err.message + "\\n\\nMake sure bus_route_planner.py --serve is running.");
  }
};

renderStops();
