# School Bus Route Planner - Interactive Map

This version adds an interactive Leaflet map to the original Dijkstra + BFS + Greedy route planner.

## 1. Open Command Prompt

Go to the project folder:

    cd C:\Users\karna\Downloads\school_bus_route_planner_interactive_map

## 2. Install Python packages

    python -m pip install -r requirements.txt

## 3. Start the API

    python bus_route_planner.py --serve

Keep this Command Prompt open.

## 4. Start the map

Open a SECOND Command Prompt:

    cd C:\Users\karna\Downloads\school_bus_route_planner_interactive_map\frontend
    python -m http.server 8000

## 5. Open the app

Go to:

    http://127.0.0.1:8000

## Map controls

- Click **Set School**, then click the map.
- Click **Add Stop**, then click the map to add student stops.
- Stop markers can be dragged.
- Edit each stop's student count and priority in the right panel.
- Set bus capacity.
- Click **Plan Route** to calculate and draw the route.
- Click **Clear** to start over.

The map uses OpenStreetMap tiles through Leaflet. The route calculation itself runs in your Python API. The map version creates geographic edges between the school and stops using straight-line distance, then applies the project's existing Dijkstra/BFS/Greedy logic.

## Project files

- `bus_route_planner.py` — Python algorithms + Flask API
- `frontend/index.html` — map page
- `frontend/app.js` — map, stops and route display
- `frontend/style.css` — page styling
- `requirements.txt` — Flask dependencies


## Extra features in the final version

- Save the current school, stops, priorities and capacity to `bus_route_plan.json`.
- Load a previously saved route plan.
- Clear the route and start a new plan.
- Clear route display automatically when a marker is moved.
- Map legend and distinct school/stop markers.
- Route path and unreachable-stop information are shown after planning.

### Note

The planner uses the map coordinates to calculate geographic distances and then runs
the project's Dijkstra, BFS and Greedy algorithms. It does not require a paid map API key.
The browser downloads OpenStreetMap map tiles when the map is opened.
