"""
School Bus Route Planner
Dijkstra (least-cost paths) + BFS (reachability / min hops) + Greedy (pickup order)
Interactive map API: accepts stops with latitude/longitude and returns route geometry.
"""

import heapq
import math
import sys
from collections import deque

ROADS = [
    ("School", "A", 3), ("A", "B", 2), ("A", "C", 4),
    ("B", "D", 3), ("C", "D", 2), ("School", "C", 5),
]

STOPS = {
    "A": {"students": 5, "priority": "High"},
    "B": {"students": 8, "priority": "Medium"},
    "C": {"students": 4, "priority": "High"},
    "D": {"students": 6, "priority": "Low"},
}

CAPACITY = 40
AVG_SPEED_KMPH = 30
PRIORITY_WEIGHT = {"High": 3, "Medium": 2, "Low": 1}


def build_graph(roads):
    graph = {}
    for u, v, w in roads:
        if w < 0:
            raise ValueError("Dijkstra requires non-negative edge weights")
        graph.setdefault(u, {})[v] = w
        graph.setdefault(v, {})[u] = w
    return graph


def bfs(graph, start):
    hops = {start: 0}
    queue = deque([start])
    while queue:
        node = queue.popleft()
        for nxt in graph.get(node, {}):
            if nxt not in hops:
                hops[nxt] = hops[node] + 1
                queue.append(nxt)
    return hops


def dijkstra(graph, source):
    dist = {n: float("inf") for n in graph}
    prev = {}
    dist[source] = 0
    heap = [(0, source)]
    while heap:
        d, node = heapq.heappop(heap)
        if d > dist[node]:
            continue
        for nxt, w in graph[node].items():
            nd = d + w
            if nd < dist[nxt]:
                dist[nxt] = nd
                prev[nxt] = node
                heapq.heappush(heap, (nd, nxt))
    return dist, prev


def build_path(prev, source, target):
    if target == source:
        return [source]
    path, node = [target], target
    while node != source:
        if node not in prev:
            raise ValueError(f"No path from {source} to {target}")
        node = prev[node]
        path.append(node)
    return path[::-1]


def greedy_order(graph, school, stops, capacity):
    current, load, remaining = school, 0, dict(stops)
    order, log = [], []
    while remaining:
        dist, _ = dijkstra(graph, current)
        candidates = []
        for s, info in remaining.items():
            if dist.get(s, float("inf")) == float("inf"):
                log.append(f"Skip {s}: unreachable")
                continue
            if load + info["students"] > capacity:
                log.append(
                    f"Skip {s}: capacity exceeded "
                    f"({load}+{info['students']} > {capacity})"
                )
                continue
            score = dist[s] / PRIORITY_WEIGHT.get(info["priority"], 1)
            candidates.append((score, s, dist[s]))
        if not candidates:
            break
        score, best, d = min(candidates)
        load += remaining[best]["students"]
        log.append(
            f"From {current} pick {best} "
            f"(dist={d:.2f}, priority={remaining[best]['priority']}, "
            f"score={score:.2f}); load={load}/{capacity}"
        )
        order.append(best)
        current = best
        del remaining[best]
    return order, load, log


def plan_route(roads=ROADS, stops=STOPS, capacity=CAPACITY, school="School"):
    graph = build_graph(roads)
    if school not in graph:
        raise ValueError(f"School node '{school}' is not present in roads")

    reach = bfs(graph, school)
    reachable = {s: i for s, i in stops.items() if s in reach}
    unreachable = [s for s in stops if s not in reach]

    order, load, log = greedy_order(graph, school, reachable, capacity)

    full_path, total, current = [school], 0.0, school
    for stop in order + [school]:
        dist, prev = dijkstra(graph, current)
        if stop not in dist or dist[stop] == float("inf"):
            continue
        segment = build_path(prev, current, stop)
        full_path += segment[1:]
        total += dist[stop]
        current = stop

    return {
        "pickup_order": [school] + order + [school],
        "full_path": full_path,
        "total_distance_km": round(total, 2),
        "estimated_time_min": round(total / AVG_SPEED_KMPH * 60),
        "students_picked": load,
        "capacity": capacity,
        "priority_stops_served": sum(
            1 for s in order if stops[s].get("priority") == "High"
        ),
        "min_hops_from_school": reach,
        "unreachable_stops": unreachable,
        "decision_log": log,
    }


def haversine_km(a, b):
    lat1, lon1 = math.radians(a["lat"]), math.radians(a["lng"])
    lat2, lon2 = math.radians(b["lat"]), math.radians(b["lng"])
    dlat, dlon = lat2 - lat1, lon2 - lon1
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    return 6371.0088 * 2 * math.asin(math.sqrt(h))


def build_map_graph(school, stops):
    """Build a complete undirected graph from map coordinates.

    Every stop is reachable. Edge weights are geographic straight-line
    distances in km. This keeps the original Dijkstra/BFS/Greedy algorithms
    useful without requiring an external routing service.
    """
    points = {"School": school, **stops}
    names = list(points)
    roads = []
    for i, u in enumerate(names):
        for v in names[i + 1:]:
            roads.append((u, v, haversine_km(points[u], points[v])))
    return roads


def plan_map_route(school, stops, capacity=CAPACITY):
    roads = build_map_graph(school, stops)
    result = plan_route(roads, {
        name: {
            "students": int(info.get("students", 1)),
            "priority": info.get("priority", "Medium")
        }
        for name, info in stops.items()
    }, capacity)

    points = {"School": school, **stops}
    route_coordinates = []
    for name in result["full_path"]:
        p = points[name]
        route_coordinates.append([p["lat"], p["lng"]])

    result["route_coordinates"] = route_coordinates
    result["points"] = points
    return result


def create_app():
    from flask import Flask, jsonify, request
    try:
        from flask_cors import CORS
    except ImportError:
        CORS = None

    app = Flask(__name__)
    if CORS:
        CORS(app)

    @app.get("/api/health")
    def health():
        return jsonify({"ok": True})

    @app.post("/api/plan")
    def api_plan():
        body = request.get_json(silent=True) or {}

        # New interactive-map format.
        if body.get("school") and body.get("stops"):
            try:
                return jsonify(plan_map_route(
                    body["school"],
                    body["stops"],
                    int(body.get("capacity", CAPACITY))
                ))
            except Exception as exc:
                return jsonify({"error": str(exc)}), 400

        # Original API remains supported.
        roads = [tuple(r) for r in body.get("roads", ROADS)]
        try:
            return jsonify(plan_route(
                roads,
                body.get("stops", STOPS),
                body.get("capacity", CAPACITY)
            ))
        except Exception as exc:
            return jsonify({"error": str(exc)}), 400

    return app


if __name__ == "__main__":
    if "--serve" in sys.argv:
        create_app().run(debug=True, port=5000)
    else:
        r = plan_route()
        print("Route   :", " -> ".join(r["pickup_order"]))
        print("Path    :", " -> ".join(r["full_path"]))
        print(
            f"Distance: {r['total_distance_km']} km | "
            f"Time: {r['estimated_time_min']} min | "
            f"Students: {r['students_picked']}/{r['capacity']} | "
            f"Priority stops: {r['priority_stops_served']}"
        )
        print("BFS hops:", r["min_hops_from_school"])
        print("\nWhy this route (greedy decisions):")
        for line in r["decision_log"]:
            print("  -", line)
